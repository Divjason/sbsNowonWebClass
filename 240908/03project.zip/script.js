const items = document.querySelectorAll("article");
const aside = document.querySelector("aside");
const close = aside.querySelector("span");

items.forEach((item) => {
  // article mouseenter event
  item.addEventListener("mouseenter", (e) => {
    e.target.querySelector("video").play();
  });
  item.addEventListener("mouseleave", (e) => {
    e.target.querySelector("video").pause();
  });

  // article mouseclick event
  item.addEventListener("click", (e) => {
    const tit = e.currentTarget.querySelector("h2").innerText;
    const txt = e.currentTarget.querySelector("p").innerText;
    const vidSrc = e.currentTarget.querySelector("video").getAttribute("src");

    aside.querySelector("h1").innerText = tit;
    aside.querySelector("p").innerText = txt;
    aside.querySelector("video").setAttribute("src", vidSrc);

    aside.querySelector("video").play();
    aside.classList.add("on");
  });

  // close event
  close.addEventListener("click", () => {
    aside.classList.remove("on");
    aside.querySelector("video").pause();
  });
});
