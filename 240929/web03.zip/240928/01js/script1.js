// 1.사용자에게 어떤 숫자 값을 전달 받음
// 2.사용자가 입력한 그 숫자가 소수인지 아닌지 여부 판단
// 3.만약 사용자가 입력한 숫자가 소수라면, 소수입니다!
// 4.만약 사용자가 입력한 숫자가 소수가 아니라면, 소수가 아닙니다!
// 5.만약 소수도 합성수도 아니면, 소수 및 합성수가 아닙니다!

// 소수 : 1과 본인자신으로만 나눌 수 있는 숫자
// ex.3, 7, 13
// 합성수 : 둘 이상의 소수를 곱한 자연수
// 소수도 합성수도 아닌 숫자 => 1

const number = parseInt(prompt("자연수를 입력하세요!"));
let isPrime;

if (!isNaN(number)) {
  if (number === 1) document.write(`${number}은 소수도 합성수도 아닙니다.`);
  else if (number === 2) {
    document.write(`${number}는 소수입니다!`);
    isPrime = true;
  } else {
    for (let i = 2; i < number; i++) {
      if (number % i === 0) {
        isPrime = false;
        break;
      } else isPrime = true;
    }
  }
} else {
  alert("정상적인 값을 입력하세요!");
  location.reload();
}

if (isPrime) document.write(`${number}는 소수입니다!`);
else document.write(`${number}는 소수가 아닙니다!`);
