// // 함수 호출!
// fnc();

// // 함수 선언!
// function fnc() {
//   console.log("이것이 함수다!");
// }

// function fnc01() {
//   console.log("이것이 함수다!");
// }

// const fnc02 = function () {
//   console.log("이것이 함수다!");
// };

// const fnc03 = () => {
//   console.log("이것이 함수다!");
// };

// const calcSum = () => {
//   let sum = 0;
//   for (let i = 1; i <= 10; i++) {
//     sum += i;
//   }
//   console.log(`1부터 10까지 더하면 ${sum}입니다!`);
// };

// calcSum();

const num01 = parseInt(prompt("첫 번째 숫자!"));
const num02 = parseInt(prompt("두 번째 숫자!"));

const sum = (a, b) => {
  const result = a + b;
  alert(`두 수의 합은 ${result} 입니다.`);
};

sum(num01, num02);
