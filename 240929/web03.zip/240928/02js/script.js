// TodoList
const form = document.querySelector("form");
const input = document.querySelector("input[type='text']");
const ul = document.querySelector("ul");

let todos = [];

const save = () => {
  localStorage.setItem("todos", JSON.stringify(todos));
};

const delItem = (e) => {
  e.preventDefault();
  const target = e.target.parentElement;
  todos = todos.filter((todo) => todo.id !== Number(target.id));
  save();
  target.remove();
};

const addItem = (todo) => {
  if (todo.text !== "") {
    const li = document.createElement("li");
    const span = document.createElement("span");
    const button = document.createElement("button");

    span.innerText = todo.text;
    button.innerText = "완료";
    button.addEventListener("click", delItem);

    li.id = todo.id;
    li.append(span, button);
    ul.appendChild(li);
  }
};

const handler = (e) => {
  e.preventDefault();
  const todo = {
    id: Date.now(),
    text: input.value,
  };
  todos.push(todo);
  addItem(todo);
  save();
  input.value = "";
};

const init = () => {
  const userTodos = JSON.parse(localStorage.getItem("todos"));
  if (userTodos) {
    userTodos.forEach((todo) => addItem(todo));
    todos = userTodos;
  } else userTodos = todos;
};

init();

form.addEventListener("submit", handler);

// Weather API
import { API_KEY } from "./env.js";
const getCurrentWeater = (latitude, longitude) => {
  const URL = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${API_KEY}`;

  fetch(URL)
    .then((response) => response.json())
    .then(({ name }) => {
      const city = document.querySelector(".city");
      let cityName;
      switch (name) {
        case "Guri-si":
          cityName = "구리시";
          break;
      }
      city.innerText = `🎪현재위치 : 서울시 ${cityName}`;
    });
};

const getPosition = (position) => {
  const { latitude, longitude } = position.coords;
  getCurrentWeater(latitude, longitude);
};

const errorHandler = (error) => {
  console.error(`${error.message}`);
  const notice = document.querySelector(".notice");
  notice.style.display = "block";
};

if ("geolocation" in navigator)
  window.navigator.geolocation.getCurrentPosition(getPosition, errorHandler);
else console.log("geolocation is not available!");
