// 1.사용자로부터 나이를 입력받는다.
// DOM을 제어한다
// html을 통해서 작성한 form 요소 내부에 있는 input 태그 값을 찾아와야 한다!!

// 2.사용자의 나이가 성인인지 여부를 판단하는 기능을 구현
// 조건문을 사용해서 성인여부를 체크!!!

// 3.성인 여부에 따라서 알림창을 띄운다.
// alert()를 활용해서 알림창을 띄운다.

const form = document.querySelector("form");

const authentication = (e) => {
  e.preventDefault();
  let input = document.querySelector("input[type='text']").value;

  if (input !== "") {
    if (input >= 20) alert("성인입니다!");
    else alert("미성년자 입니다!");
  } else alert("당신의 나이를 정상적인 숫자로 입력하세요!");

  document.querySelector(".age").value = "";
};

form.addEventListener("submit", authentication);
