let a = 100;
let b = a;

b = 20;

console.log(a, b);

let obj = {
  a: 1,
  b: 2,
  c: 3,
};
// let newObj = { ...obj }; => 느슨한 독립
let newObj = JSON.parse(JSON.stringify(obj)); // 엄격한 독립

newObj.a = 100;

console.log(obj, newObj);
