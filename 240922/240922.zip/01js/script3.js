// if(조건식 => true) { 실행문 }

// const x = 10;

// if (x < 5) {
//   console.log("X는 5보다 큽니다!");
// }

// if(조건식 => true) {
//   실행문 실행!
// } else {
//   두번째 실행문 실행!
// }

// const num = parseInt(prompt("당신이 좋아하는 숫자를 입력하세요!"));

// if (num % 2 === 0) console.log("당신이 좋아하는 숫자는 짝수입니다!");
// else console.log("당신이 좋아하는 숫자는 홀수입니다!");

// const score = prompt("당신의 프로그래밍 점수는?");

// if (score && score !== null) {
//   if (parseInt(score) >= 90) alert("A학점");
//   else if (parseInt(score) >= 80) alert("B학점");
//   else alert("C학점");
// } else {
//   alert("정확한 점수를 입력하세요!");
// }

// const month = parseInt(prompt("현재는 몇 월 입니까?", 10));

// if (9 <= month && month <= 11) alert("독서의 계절, 가을!");
// else if (6 <= month && month <= 8) alert("여행가기 좋은 여름!");
// else if (3 <= month && month <= 5) alert("햇살 가득한 봄!");
// else alert("스키의 계절, 겨울!");

// 사용자에게 id값과 password값을 받아서 정상적인 값이면 환영합니다! 라는 메세지를 전달하고, 만약 id 혹은 password값이 둘중에 하나라도 틀리다면, 정확한 값을 입력하세요! 라는 메세지를 전달하는 프로그램을 개발!!!

// id = "sbs"
// pw = "1234"

// 1.사용자에게 ID값을 받는다
// 2.사용자가 입력한 ID값과 우리가 변수에 저장해놓은 id값을 비교해서 만약 같으면 PW값을 받도록 한다
// 3.만약 입력한 ID값과 변수 내 id값이 서로 상이하다면, id재입력을 요구한다.
// 4.사용자로부터 PW값을 받는다
// 5.사용자에게 받은 PW값을 비교한다.

const id = "sbs";
const pw = 1234;

const user_id = prompt("당신의 아이디는?");

if (user_id !== null) {
  if (id === user_id) {
    const user_pw = parseInt(prompt("당신의 비밀번호는?"));
    if (pw === user_pw) {
      alert(`${user_id}님 반갑습니다!`);
    } else {
      alert("비밀번호가 일치하지 않습니다!");
      location.reload();
    }
  } else {
    alert("아이디가 일치하지 않습니다!");
    location.reload();
  }
} else {
  alert("정상적인 아이디를 입력하세요!");
  location.reload();
}
