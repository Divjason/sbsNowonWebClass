const traffic = parseInt(prompt("😎교통비를 입력하세요!", 5000));
const eat = parseInt(prompt("🤣식비를 입력하세요!", 5000));
const drink = parseInt(prompt("😜음료비를 입력하세요!", 5000));

const sum = traffic + eat + drink;

let result = sum < 10000;

const good = 10000 - sum;
const bad = sum - 10000;

result = result
  ? `${good}원 남았습니다! 돈 관리 잘하셨어요!💕`
  : `${bad}원 초과했습니다! 절약해주세요!😢`;

alert(result);
