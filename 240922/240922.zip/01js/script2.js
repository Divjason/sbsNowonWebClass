// const num01 = 10;
// const num02 = 2;
// let num03 = 0;

// const result = num01 % num02;

// const result01 = ++num03;

// console.log(result);
// console.log(result01);

// let x = 10;
// let y = 4;

// let result = x + ++y;

// console.log(result);

// console.log(y);

// const name = "아이유";
// const number = 64;

// const result = name + "씨는 " + number + "만명의 팬이있다.";

// console.log(result);

// const num04 = 10;
// let sum = 0;

// // sum = sum + num04;
// sum += num04;

// console.log(sum);

// let str = "<table border='1'>";

// str += "<tr>";
// str += "<td>1</td><td>2</td><td>3</td>";
// str += "</tr>";

// str += "</table>";

// console.log(str);
// document.write(str);

// const a = 10;
// const b = 20;

// console.log(a > 10 || b > 10);
