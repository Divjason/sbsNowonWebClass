// 사용자의 태어난 년도를 확인해서 사용자의 나이를 알려주는 프로그램을 만들어보세요!!!
// const birthYear = parseInt(prompt("태어난 년도를 입력하세요!"));
// const currentYear = new Date().getFullYear();
// const age = currentYear - birthYear + 1;

// alert(`당신의 나이는 ${age}입니다!`);

// 사용자에게 이름 & 키 & 몸무게 정보를 받아서 사용자의 현재 몸무게가 적정체중인지 아니면 적정체중이 아닌지를 판단해서 알려주는 프로그램을 개발!!!!

// 1.사용자에게 정보를 받는다 (*이름, 키, 몸무게)
// 2.적정체중인지를 계산할 수 있는 기능
// 3.적정체중 여부를 확인 후 출력

const name = prompt("😎이름을 입력하세요!", "홍길동");
const height = parseFloat(prompt("😂키를 입력하세요", 180));
const weight = parseFloat(prompt("🤣몸무게를 입력하세요", 68));

const normalWeight = (height - 100) * 0.9;
let result = weight >= normalWeight - 5 && weight <= normalWeight + 5;
result = result ? "적정체중이시네요!👍" : "적정체중이아니네요!😢";

alert(`${name}님은 ${result}💕`);
