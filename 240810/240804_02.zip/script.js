const trigger = document.querySelector(".trigger");
const modalGnb = document.querySelector(".modal-gnb");

trigger.addEventListener("click", function () {
  this.classList.toggle("active");
  modalGnb.classList.toggle("active");
});
