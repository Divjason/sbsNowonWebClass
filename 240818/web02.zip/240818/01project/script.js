const userName = prompt("당신의 이름을 입력해주세요!");
const result = document.querySelector(".result");

setTimeout(() => {
  document.querySelector(".loading").classList.add("active");
  result.innerText = userName;
}, 3000);

// 프로그래밍언어 VS 인간세계

// 각도
// 60분법 VS 호도법 => 라디안
// 부채꼴
// 파이 = 3.14 = 180도

// 시간
// 밀리초 => 1초 = 1000밀리초
// 1분 = (60 * 1000)
// 1시간 = (60 * 60 * 1000)
// 1일 = (24 * 60 * 60 * 1000)
