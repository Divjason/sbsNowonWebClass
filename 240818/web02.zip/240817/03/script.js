let num = 10;
console.log(typeof num);

num = "10";
console.log(typeof num);

// TS
// let num:Number = 10;

// React.js
// 자바스크립트의 라이브러리
// 자바스크립트로 만들어야 하는 기능 => 만들어놓았고,
// 페이스북
// 10억명
// 기존 html, css, js 모든 페이지 ssr
// server side rendering
// csr = client side rendering
// SEO = 검색최적화

// 자바스크립트 프레임워크
// 부트스트랩

// F/E
// html5, css3, scss, JS, React.js, Tailwind, Styled Component, Redux, Recoil, TS, Next.js, Node.js, MySQl, sql, MongoDB, Mongoose, Babel, AWS, Docker

//

// Naver, kakao => Vue.js
// MS, Google => Angluar.js

// const article = document.querySelectorAll("article");

// console.log(article);
