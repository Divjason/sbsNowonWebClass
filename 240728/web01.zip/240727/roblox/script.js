const femaleBtn = document.querySelector("#female");
const maleBtn = document.querySelector("#male");

femaleBtn.addEventListener("click", (e) => {
  e.preventDefault();
  const femaleIcon = femaleBtn.querySelector("i");
  const maleIcon = maleBtn.querySelector("i");
  femaleIcon.classList.toggle("active");
  maleIcon.classList.remove("active");
});

maleBtn.addEventListener("click", (e) => {
  e.preventDefault();
  const femaleIcon = femaleBtn.querySelector("i");
  const maleIcon = maleBtn.querySelector("i");
  femaleIcon.classList.remove("active");
  maleIcon.classList.toggle("active");
});
