const students = ["park", "kim", "lee", "kang"];

// for문 => 배열
// for (let i = 0; i < students.length; i++) {
//   document.write(`${students[i]} `);
// }

// forEach문 => 배열
// students.forEach((student, index, array) => {
//   document.write(
//     `[${array}] 배열내부에서 ${student}의 인덱스값은 ${index} <br />`
//   );
// });
// students.forEach((student, index, array) => {
//   document.write(`${student} `);
// });

// for of문 => 배열
// for (let student of students) {
//   document.write(`${student} `);
// }

// for in문 => 순수객체
// const javascript = {
//   title: "재미있는 자바스크립트",
//   pages: 272,
//   author: "David",
//   price: 25000,
// };

// for (let key in javascript) {
//   document.write(`${key} : ${javascript[key]} <br/>`);
// }

let stars = parseInt(prompt("만들고 싶은 별의 개수 :"));

// if (!isNaN(stars)) {
//   while (stars > 0) {
//     document.write("*");
//     stars--;
//   }
// } else {
//   alert("정상값을 입력하세요!");
// }

// if (stars === NaN) alert("정상적인 값을 넣어주세요!");
// console.log(isNaN(NaN));

do {
  document.write("*");
  stars--;
} while (stars > 0);
