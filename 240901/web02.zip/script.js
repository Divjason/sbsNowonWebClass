// 자바스크립트는 시간 개념 => 밀리초!!
// 1초 = 1000밀리초
// 1분 = 60 * 1000
// 1시간 = 60 * 60 * 1000
// 1일 = 24 * 60 * 60 * 1000
// 2024년 - 1970년

// const now = new Date();
// const openClass = new Date("2024-08-17");

// const gap = now - openClass;
// console.log(gap / (24 * 60 * 60 * 1000));

const getFormattedDate = () => {
  const date = new Date();
  const year = date.getFullYear();
  const month = "0" + (date.getMonth() + 1);
  const day = "0" + date.getDate();

  return `${year}-${month}-${day}`;
};

const todayDate = getFormattedDate();
const dailyCookieName = `pageHit_${todayDate}`;

const expireDate = new Date();
expireDate.setDate(expireDate.getDate() + 1);
const expireDateString = expireDate.toGMTString();
console.log(document.cookie);

const cookieVal = (cookieName) => {
  const thisCookie = document.cookie.split("; ");
  console.log(thisCookie);

  for (let i = 0; i < thisCookie.length; i++) {
    if (cookieName === thisCookie[i].split("=")[0]) {
      return thisCookie[i].split("=")[1];
    }
  }
  return 0;
};

let dailyHitCt = cookieVal(dailyCookieName);
if (isNaN(dailyHitCt)) dailyHitCt = 0;
dailyHitCt++;

let totalHitCt = cookieVal("totalPageHit");
if (isNaN(totalHitCt)) totalHitCt = 0;
totalHitCt++;

document.cookie = `${dailyCookieName}=${dailyHitCt}; expires=${expireDateString}`;
document.cookie = `totalPageHit=${totalHitCt}; expires=Fri, 31 Dec 9999 23:59:59 GMT`;

document.querySelector(".zero").innerText = dailyHitCt;
document.querySelector(".total").innerText = dailyHitCt;
