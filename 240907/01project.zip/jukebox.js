const songs = document.querySelectorAll(".albumTable_song");
songs.forEach((song) => {
  const play = song.querySelector(".fa-play");
  const pause = song.querySelector(".fa-pause");
  play.addEventListener("click", (e) => {
    e.target.closest("td").querySelector("audio").play();
  });
  pause.addEventListener("click", (e) => {
    e.target.closest("td").querySelector("audio").pause();
  });
});
