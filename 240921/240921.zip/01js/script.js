// var num01 = 1;
// let num02 = 2;
// const num03 = 3;

// console.log(num01, num02, num03);

// // num03 = 4;
// // num02 = 5;
// // console.log(num02);

// var num01 = 10;

// const numA = 10;
// const numB = 20;

// const result = numA + numB;
// console.log(result);

// const num = 7;
// const str = "7";

// const result = num + str;

// console.log(result, typeof result);

// const name = "현빈";
// const classRoom = 201;

// console.log(name + "님 " + classRoom + "호 " + "강의실로 이동해주세요!");

// console.log(`${name}님 ${classRoom}호 강의실로 이동해주세요!`);

// const result = 10 > 2;
// console.log(result);

// let username;

// console.log(typeof username);

// const javascript = {
//   title: "모던 자바스크립트",
//   pages: 272,
// };

// const title = javascript.title;
// console.log(title);

// const pages = javascript["pages"];
// console.log(pages);

// 구조분해할당
// const { title: main, pages } = javascript;
// console.log(main, pages);

// const emptyArr = [];
// emptyArr[0] = "red";
// emptyArr[1] = "blue";

// console.log(emptyArr, emptyArr.length);

// const num1 = Symbol();
// const num2 = Symbol();

// console.log(num1 === num2);

// const id = Symbol("id");

// const member = {
//   name: "David",
//   [id]: 12345,
// };

// console.log(member);

// const fnc = () => {
//   console.log("Hello");
// };

// const item01 = "4.7";
// const item02 = 10;
// const item03 = null;

// console.log(parseFloat(item01));
// console.log(parseInt(item01));
// console.log(Number(item03));

// console.log(item01 != item02);

// console.log(item02.toString(2));
// console.log(typeof String(item02));

// console.log(Boolean(undefined));
