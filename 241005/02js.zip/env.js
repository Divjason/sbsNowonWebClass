export const weatherMap = "63f74653bc784125c8b0dea992eb3d70";
export const unSplash = "IFzUR_NfqDGF660wYii-fOjKlHG_hTjxb8pGZUaGy5s";
