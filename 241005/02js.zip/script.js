// TodoList
const form = document.querySelector("form");
const input = document.querySelector("input[type='text']");
const ul = document.querySelector("ul");

let todos = [];

const save = () => {
  localStorage.setItem("todos", JSON.stringify(todos));
};

const delItem = (e) => {
  e.preventDefault();
  const target = e.target.parentElement;
  todos = todos.filter((todo) => todo.id !== Number(target.id));
  save();
  target.remove();
};

const addItem = (todo) => {
  if (todo.text !== "") {
    const li = document.createElement("li");
    const span = document.createElement("span");
    const button = document.createElement("button");

    span.innerText = todo.text;
    button.innerText = "완료";
    button.addEventListener("click", delItem);

    li.id = todo.id;
    li.append(span, button);
    ul.appendChild(li);
  }
};

const handler = (e) => {
  e.preventDefault();
  const todo = {
    id: Date.now(),
    text: input.value,
  };
  todos.push(todo);
  addItem(todo);
  save();
  input.value = "";
};

const init = () => {
  let userTodos = JSON.parse(localStorage.getItem("todos"));
  if (userTodos) {
    userTodos.forEach((todo) => addItem(todo));
    todos = userTodos;
  } else userTodos = todos;
};

init();

form.addEventListener("submit", handler);

// Weather API
import { weatherMap } from "./env.js";
const getCurrentWeater = (latitude, longitude) => {
  const URL = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${weatherMap}&units=metric`;

  fetch(URL)
    .then((response) => response.json())
    .then(({ name, main, weather }) => {
      const city = document.querySelector(".city");
      const temp = document.querySelector(".temp");
      const weatherElem = document.querySelector(".weather");
      const icon = document.querySelector(".icon");
      let cityName;
      switch (name) {
        case "Guri-si":
          cityName = "경기도 구리시";
          break;
        case "Uijeongbu-si":
          cityName = "경기도 의정부시";
          break;
      }
      let weatherName;
      switch (weather[0].main) {
        case "Clouds":
          weatherName = "구름 조금";
          break;
      }
      city.innerText = `🎪현재위치 : ${cityName}`;
      temp.innerText = `🌞현재온도 : ${main.temp} ℃`;
      weatherElem.innerText = `🌈현재날씨 : ${weatherName}`;
      icon.src = `https://openweathermap.org/img/wn/${weather[0].icon}@2x.png`;
    });
};

const getPosition = (position) => {
  const { latitude, longitude } = position.coords;
  getCurrentWeater(latitude, longitude);
};

const errorHandler = (error) => {
  console.error(`${error.message}`);
  const notice = document.querySelector(".notice");
  notice.style.display = "block";
};

if ("geolocation" in navigator)
  window.navigator.geolocation.getCurrentPosition(getPosition, errorHandler);
else console.log("geolocation is not available!");

// unSplash API
import { unSplash } from "./env.js";
const getImg = `https://api.unsplash.com/photos/random/?client_id=${unSplash}`;

fetch(getImg)
  .then((response) => response.json())
  .then(({ urls: { full } }) => {
    let img = full;
    document.body.style.backgroundImage = `url(${img})`;
    document.body.style.backgroundSize = `cover`;
    document.body.style.backgroundPosition = `center`;
  });

// clock Item
const displayDate = document.querySelector(".displayDate");
const displayTime = document.querySelector(".displayTime");

const today = new Date();
const year = today.getFullYear();
const month = today.getMonth() + 1;
const date = today.getDate();
const day = today.getDay();

let dayName = "";
switch (day) {
  case 0:
    dayName = "일요일";
    break;
  case 1:
    dayName = "월요일";
    break;
  case 2:
    dayName = "화요일";
    break;
  case 3:
    dayName = "수요일";
    break;
  case 4:
    dayName = "목요일";
    break;
  case 5:
    dayName = "금요일";
    break;
  case 6:
    dayName = "토요일";
    break;
}

displayDate.innerHTML = `${year}년 ${month}월 ${date}일 <span>${dayName}</span>`;

const clock = () => {
  const current = new Date();
  let hrs = current.getHours();
  let mins = current.getMinutes();
  let secs = current.getSeconds();

  let period = "오전";
  if (hrs === 0) hrs = 12;
  else if (hrs > 12) {
    hrs -= 12;
    period = "오후";
  }

  hrs = hrs < 10 ? `0${hrs}` : hrs;
  mins = mins < 10 ? `0${mins}` : mins;
  secs = secs < 10 ? `0${secs}` : secs;

  displayTime.innerText = `${period} ${hrs}시 ${mins}분 ${secs}초`;
};

setInterval(clock, 1000);
