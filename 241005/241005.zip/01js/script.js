// const today = new Date();

// const year = today.getFullYear();
// console.log(year);

// const month = today.getMonth();
// console.log(month + 1);

// const date = today.getDate();
// console.log(date);

// const day = today.getDay();
// console.log(day);

// const today = new Date();
// const theDay = new Date("2024-10-01");
// const gap = today - theDay;
// console.log(Math.floor(gap / (24 * 60 * 60 * 1000)));

// 1초 = 1000밀리초
// 1분 = 60초 = 60000밀리초
// 1시간 = 3600000밀리초
// 1일 = 24 * 60 * 60 * 1000

// const year = theDay.getFullYear();
// console.log(year);

// const month = theDay.getMonth();
// console.log(month + 1);

// const date = theDay.getDate();
// console.log(date);

// 밀리초 => 1초 1000밀리초
// 60분법
// 1970년 1월 1일~현재시점까지의 시간을 누적해서 환산한 숫자

const today = new Date();
const firstDay = new Date("2024-09-21");

const passedTime = today.getTime() - firstDay.getTime();
const passedDay = Math.round(passedTime / (1000 * 60 * 60 * 24));

console.log(passedDay);
